public class p16gcd_dm_discrete_se14_c187_ms7_s1_out {
	public static void main(String[] args) {
		
		Integer OutLoc = 0;
		Integer InLoc1 = Integer.parseInt(args[1]);
		Integer InLoc2 = Integer.parseInt(args[2]);
		
		long start677918735914800 = System.currentTimeMillis();
		long end677918735914800 = start677918735914800 + 5*1000;
		while(InLoc1 != InLoc2 && (System.currentTimeMillis()<end677918735914800) ) {
			if(InLoc1 > InLoc2) {
				InLoc1 = InLoc1 - InLoc2;
			} else {
				InLoc2 = InLoc2 - InLoc1;
			}
		}
		OutLoc = InLoc1;
		
		if(OutLoc==Integer.parseInt(args[0])) {
			System.out.println("Passed :) Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		} else {
			System.out.println("Failed :( Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		}
	}
}
