public class p16gcd_dm_euclidean_quadratic_se16_c7_ms7_s2_out {
	public static void main(String[] args) {
		
		Integer OutLoc = 0;
		Integer InLoc1 = Integer.parseInt(args[1]);
		Integer InLoc2 = Integer.parseInt(args[2]);
		
		long start891820236051700 = System.currentTimeMillis();
		long end891820236051700 = start891820236051700 + 5*1000;
		while(InLoc1 > InLoc2 && (System.currentTimeMillis()<end891820236051700) ) {
			InLoc1 = InLoc1 - InLoc2;
		}
		OutLoc = InLoc1;
		InLoc2 = InLoc2 - InLoc1;
		
		if(OutLoc==Integer.parseInt(args[0])) {
			System.out.println("Passed :) Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		} else {
			System.out.println("Failed :( Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		}
	}
}
