public class p16gcd_dm_euclidean_quadratic_se5_c13_ms7_s1_out {
	public static void main(String[] args) {
		
		Integer OutLoc = 0;
		Integer InLoc1 = Integer.parseInt(args[1]);
		Integer InLoc2 = Integer.parseInt(args[2]);
		
		long start839429355806000 = System.currentTimeMillis();
		long end839429355806000 = start839429355806000 + 5*1000;
		while(InLoc1 != InLoc2 && (System.currentTimeMillis()<end839429355806000) ) {
			if(InLoc1 > InLoc2) {
				InLoc1 = InLoc1 - InLoc2;
			} else {
				InLoc2 = InLoc2 - InLoc1;
			}
		}
		OutLoc = InLoc1;
		
		if(OutLoc==Integer.parseInt(args[0])) {
			System.out.println("Passed :) Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		} else {
			System.out.println("Failed :( Expected: "+args[0]+". Returned: "+ OutLoc +". ");
		}
	}
}
